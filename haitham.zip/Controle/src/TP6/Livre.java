package TP6;

public class Livre {

    private String titre;
    private String auteur;
    private boolean estDisponible;

    public Livre(String titre, String auteur, boolean estDisponible) {
        this.titre = titre;
        this.auteur = auteur;
        this.estDisponible = estDisponible;
    }
    public String getTitre() {
        return titre;
    }
    public void setTitre(String titre) {
        this.titre = titre;
    }
    public String getAuteur() {
        return auteur;
    }
    public void setAuteur(String auteur) {
        this.auteur = auteur;
    }
    public boolean getEstDisponible() {
        return estDisponible;
    }
    public void setEstDisponible(boolean estDisponible) {
        this.estDisponible = estDisponible;
    }

    @Override public String toString() {
        return ("le titre:" + this.getTitre() +"l auteur:" + this.getAuteur() +"Disponibilite :" + this.getEstDisponible());
    }
    public void emprunter(){
        this.setEstDisponible(false);
    }
    public void retourner(){
        this.setEstDisponible(true);
    }
}
