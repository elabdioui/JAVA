package TP6;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class GestionBibliotheque {
    private Map<Utilisateur, ArrayList<Livre>> map;

    public GestionBibliotheque( HashMap<Utilisateur, ArrayList<Livre>> map ) {
        this.map = map;
    }

    public void Ajouter (Utilisateur utilisateur, ArrayList<Livre> livres) {
        map.put(utilisateur,livres);

    }
    public void Afficher () {
    for (Utilisateur utilisateur : map.keySet()) {
    for (Livre livre : map.get(utilisateur)) {
        System.out.println(utilisateur.getNom() + " " + livre.getTitre());
    }
    }
    }
}
