package TP6;

import java.util.ArrayList;

public class Utilisateur {

    private String nom;
    private ArrayList<Livre> livres;

    public Utilisateur(String nom, ArrayList<Livre> livres) throws LivreEmpruntException {
        this.nom = nom;
        if (livres.size() > 5) throw new LivreEmpruntException();
        this.livres = livres;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public ArrayList<Livre> getLivres() {
        return livres;
    }

    public void setLivres(ArrayList<Livre> livres) throws LivreEmpruntException {

        if (livres.size() > 5) throw new LivreEmpruntException();
        else this.livres = livres;
    }

    public void ajouterLivre(Livre livre) {
        this.livres.add(livre);
    }

    public void EmprunterLivrer(Livre livre) throws LivreEmpruntException {
        if (this.livres.size() > 5) throw new LivreEmpruntException();
        else {
            livre.emprunter();
            livres.add(livre);
        }
    }

    public void RetourLivre(Livre livre) {
        livre.retourner();
        livres.remove(livre);
    }

    public void AfficherLivre() {
        for (Livre livre : livres) {
            if (livre.getEstDisponible() == false)
                System.out.println(livre);
        }
    }

}