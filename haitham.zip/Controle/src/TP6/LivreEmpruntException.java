package TP6;

public class LivreEmpruntException extends Exception {
    public LivreEmpruntException() {

        super("il est impossible d emprunter plus que 5 livres ");
    }
}
