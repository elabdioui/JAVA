import TP6.GestionBibliotheque;
import TP6.Livre;
import TP6.LivreEmpruntException;
import TP6.Utilisateur;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Main {

    public static void main(String[] args) throws LivreEmpruntException {

        Livre livre = new Livre("t1","a1",true);
        Livre livre2 = new Livre("t2","a2",false);
        Livre livre3 = new Livre("t3","a3",false);
        Livre livre4 = new Livre("t4","a4",true);
        Livre livre5 = new Livre("t5","a5",false);
        Livre livre6 = new Livre("t6","a6",true);

        ArrayList<Livre> list1 = new ArrayList<>(Arrays.asList(livre,livre2));
        ArrayList<Livre> list2 = new ArrayList<>(Arrays.asList(livre3,livre4));
        ArrayList<Livre> list3= new ArrayList<>(Arrays.asList(livre5,livre6));
        ArrayList<Livre> list4 = new ArrayList<>(Arrays.asList(livre,livre2,livre3,livre4,livre5,livre6));

        Utilisateur u1 = new Utilisateur("haitham",list1);
        Utilisateur u2 = new Utilisateur("haitham2",list2);
        Utilisateur u3 = new Utilisateur("haitham3",list3);

        HashMap <Utilisateur, ArrayList<Livre>> map = new HashMap<Utilisateur, ArrayList<Livre>>();



       GestionBibliotheque gb = new GestionBibliotheque(map);

       gb.Ajouter(u1,list1);
       gb.Ajouter(u2,list2);
       gb.Ajouter(u3,list3);

       gb.Afficher();

       u1.setLivres(list4);


    }
}